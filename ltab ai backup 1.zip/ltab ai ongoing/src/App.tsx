import React from 'react';
import AiGallery from './pages/AiGallery';

function App() {
  return <AiGallery />;
}

export default App;